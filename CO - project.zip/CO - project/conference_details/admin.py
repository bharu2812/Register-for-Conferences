from django.contrib import admin
from .models import Conference

# Register your models here.
@admin.register(Conference)
class ConferenceAdmin(admin.ModelAdmin):
    list_display=['C_Title','C_Date','C_Deadline','C_Authortype','C_Contact']


