from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.mainpage , name="mainpage"),
    path('homepage', views.con_homepage , name="conferencehome"),
    path('impdates', views.datesimp , name="impdates"),
    path('regdetails', views.reg , name="regdetails"),
    path('contactdetails', views.contact , name="contactdetails"),

]