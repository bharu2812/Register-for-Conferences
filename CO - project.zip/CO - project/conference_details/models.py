from django.db import models

AUTHOR_CHOICES  = (
    ("Foreign Authors", "Foreign Authors"),
    ("Indian Authors", "Indian Authors"),
)


class Conference(models.Model):
    C_Title = models.CharField(max_length=120)
    C_Date = models.DateField()
    C_Deadline = models.DateField()
    C_Authortype = models.CharField(max_length = 20,choices = AUTHOR_CHOICES,default="Foreign Authors")
    C_Contact = models.BigIntegerField()
