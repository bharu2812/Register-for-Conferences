from django.shortcuts import render
from conference_details.models import *

def mainpage(request):
    if request.method == "GET":
        return render(request, "mainpage.html")

def con_homepage(request):
    if request.method == "GET":
        items = Conference.objects.all()
        return render(request, "home.html",{"items":items})

def datesimp(request):
    if request.method == "GET":
        items = Conference.objects.all()
        return render(request, "dates.html",{"items":items}) 

def reg(request):
    if request.method == "GET":
        items = Conference.objects.all()
        status=[]
        for i in items:
            print(i.C_Authortype)
            if i.C_Authortype == "Foreign Authors":
                status.append("$150 per paper")
            else:
                status.append("Rs.7500 per paper")
        res=dict(zip(items,status))
        return render(request, "regdetails.html",{"res":res}) 

def contact(request):
    if request.method == "GET":
        items = Conference.objects.all()
        return render(request, "contact.html",{"items":items}) 

